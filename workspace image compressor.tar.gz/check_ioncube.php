<?php
/**
 * Диагностика сервера под модуль "Image COMPRESSOR & Watermark & WebP & Lazy Load" by Sitecreator (ver. 3.2.0)
 * Как использовать:
 *   1. Загрузите этот файл в корень сайта (там, где index.php) — через файловый менеджер Beget или FTP.
 *   2. Откройте в браузере: https://ВАШ-ДОМЕН/check_ioncube.php
 *   3. После проверки ОБЯЗАТЕЛЬНО удалите файл с сервера!
 */
header('Content-Type: text/html; charset=utf-8');

function row($label, $value, $ok = null) {
    $color = $ok === null ? '#333' : ($ok ? '#0a7d00' : '#c00');
    $mark  = $ok === null ? '' : ($ok ? ' &#10004;' : ' &#10008;');
    echo "<tr><td style='padding:6px 12px;border:1px solid #ccc;background:#f7f7f7'><b>{$label}</b></td>"
       . "<td style='padding:6px 12px;border:1px solid #ccc;color:{$color}'>{$value}{$mark}</td></tr>";
}

echo "<h2 style='font-family:Arial'>Проверка сервера для модуля Компрессор by Sitecreator 3.2.0</h2>";
echo "<table style='border-collapse:collapse;font-family:Arial;font-size:14px'>";

// --- PHP ---
$phpv = phpversion();
$phpOk = version_compare($phpv, '5.6.0', '>=') && version_compare($phpv, '8.0.0', '<');
row('Версия PHP', $phpv . ' (модулю 3.2.0 нужно 5.6–7.4)', $phpOk);

// --- ionCube Loader ---
if (extension_loaded('ionCube Loader')) {
    $icv = phpversion('ionCube Loader');
    $iv  = function_exists('ioncube_loader_iversion') ? ioncube_loader_iversion() : 0;
    row('ionCube Loader', $icv . ' (iversion: ' . $iv . ')', null);
    // Для модуля 3.2.0: подходят 10.x, 11.x и 12.0.4+; версии 12.0.0–12.0.3 содержат баг
    if ($iv >= 100000 && $iv < 120000) {
        $icOk = true;  $icMsg = 'ПОДХОДИТ (версия 10.x или 11.x)';
    } elseif ($iv >= 120004) {
        $icOk = true;  $icMsg = 'ПОДХОДИТ (12.0.4 или новее, включая 13.x)';
    } elseif ($iv >= 120000) {
        $icOk = false; $icMsg = 'НЕ ПОДХОДИТ: версии 12.0.0–12.0.3 содержат баг. Просите поддержку Beget обновить ionCube до 12.0.4+, либо запросите у автора модуля версию 5.0.0';
    } elseif ($iv > 0) {
        $icOk = false; $icMsg = 'НЕ ПОДХОДИТ: нужен ionCube Loader версии 10 или выше';
    } else {
        $icOk = null;  $icMsg = 'не удалось определить числовую версию — сверьтесь с секцией "ionCube Loader" в phpinfo() ниже';
    }
    row('Вывод по ionCube', $icMsg, $icOk);
} else {
    row('ionCube Loader', 'НЕ УСТАНОВЛЕН / не загружен — напишите в поддержку Beget', false);
}

// --- Лимиты PHP ---
$ml = ini_get('memory_limit');
row('memory_limit', $ml . ' (нужно ≥128M, минимум 64M)', null);
row('upload_max_filesize', ini_get('upload_max_filesize') . ' (для установки через ocmod нужно ≥12–16M)', null);
row('post_max_size', ini_get('post_max_size') . ' (нужно ≥12–16M)', null);
row('max_execution_time', ini_get('max_execution_time') . ' сек', null);

// --- Расширения и функции ---
row('Расширение zip', extension_loaded('zip') ? 'есть' : 'НЕТ (без него не работает ocmod-установщик)', extension_loaded('zip'));
row('Расширение gd', extension_loaded('gd') ? 'есть' : 'нет', extension_loaded('gd'));
row('WebP в GD (imagewebp)', function_exists('imagewebp') ? 'поддерживается' : 'не поддерживается (не критично — модуль ставит свой cwebp)', null);
row('Расширение imagick', extension_loaded('imagick') ? 'есть (модуль использует его автоматически — это плюс к качеству)' : 'нет (необязательно)', null);
row('Функция proc_open', function_exists('proc_open') ? 'доступна' : 'заблокирована (нормально: для WebP не обязательна, нужна только для mozjpeg/optipng)', null);
row('Функция exec', function_exists('exec') ? 'доступна' : 'заблокирована (не критично для WebP)', null);
row('ОС / разрядность', PHP_OS . ' ' . (PHP_INT_SIZE === 8 ? '64-bit' : '32-bit') . ' (софт модуля рассчитан на Linux 64-bit)', null);

echo "</table>";

echo "<h3 style='font-family:Arial'>Полный phpinfo() — секцию «ionCube Loader» ищите поиском по странице (Ctrl+F)</h3>";
phpinfo();
echo "<p style='font-family:Arial;color:#c00'><b>Не забудьте удалить файл check_ioncube.php с сервера после проверки!</b></p>";
