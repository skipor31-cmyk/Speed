<?php
/**
 * Исправленный фид Google Sitemap для OpenCart 3.x (LiveStore 3 + SeoPro)
 * ---------------------------------------------------------------------
 * Файл:  catalog/controller/extension/feed/google_sitemap.php
 *
 * ЧТО ИСПРАВЛЕНО по сравнению с текущей версией на сайте:
 *  1. ДЕДУПЛИКАЦИЯ: каждый URL выводится ровно один раз
 *     (сейчас одна и та же страница повторяется до 26 раз: 5118 записей
 *      при 620 уникальных URL).
 *  2. Главная страница ДОБАВЛЕНА в карту сайта (сейчас её там нет).
 *  3. Категории выводятся ВСЕ (рекурсивно, с полным path=1_5_12),
 *     а не только "top"-уровня.
 *  4. lastmod выводится только для валидных дат (сейчас в sitemap
 *     попадают нулевые даты вида -0001-11-30T00:00:00+02:30).
 *  5. Один <url> = одна страница; картинка товара — один блок <image:image>
 *     внутри него (корректный формат image-sitemap по документации Google).
 *  6. XML-экранирование названий (htmlspecialchars) — защита от битого XML.
 *
 * ВАЖНО ПЕРЕД УСТАНОВКОЙ:
 *  - Сделайте резервную копию текущего файла!
 *  - В OpenCart 3 модификаторы могут перекрывать исходный файл. Проверьте,
 *    нет ли копии по пути:
 *      system/storage/modification/catalog/controller/extension/feed/google_sitemap.php
 *    Если есть — править/заменять нужно именно её (иначе изменения не применятся).
 *  - ЧПУ для страниц «Оплата/Подарки/Помощь» и статей блога появляются в
 *    sitemap автоматически, как только будут созданы SEO URL в SeoPro
 *    (см. ИНСТРУКЦИЯ.md, шаг 4). До этого они будут выводиться как
 *    index.php?route=... — как и сейчас.
 *  - Статьи блога (prostore_blog) этим фидом НЕ выводятся: они хорошо
 *    находятся роботом по внутренним ссылкам из хабов /shopblog/*.
 *    Их добавление имеет смысл после перевода блога на ЧПУ.
 */

class ControllerExtensionFeedGoogleSitemap extends Controller {
	public function index() {
		if ($this->config->get('feed_google_sitemap_status')) {
			$output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
			$output .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

			// Массив для дедупликации: URL => true
			$seen = array();

			// ------------------------------------------------------------------
			// 1. ГЛАВНАЯ СТРАНИЦА
			// ------------------------------------------------------------------
			$home = $this->url->link('common/home');

			if (!isset($seen[$home])) {
				$seen[$home] = true;

				$output .= '<url>' . "\n";
				$output .= '  <loc>' . $home . '</loc>' . "\n";
				$output .= '  <changefreq>daily</changefreq>' . "\n";
				$output .= '  <priority>1.0</priority>' . "\n";
				$output .= '</url>' . "\n";
			}

			// ------------------------------------------------------------------
			// 2. ТОВАРЫ (только активные, с date_available <= now — логика модели)
			// ------------------------------------------------------------------
			$this->load->model('catalog/product');
			$this->load->model('tool/image');

			$products = $this->model_catalog_product->getProducts(array());

			foreach ($products as $product) {
				$link = $this->url->link('product/product', 'product_id=' . (int)$product['product_id']);

				if (isset($seen[$link])) {
					continue;
				}

				$seen[$link] = true;

				$output .= '<url>' . "\n";
				$output .= '  <loc>' . $link . '</loc>' . "\n";
				$output .= '  <changefreq>weekly</changefreq>' . "\n";

				// lastmod: только если дата реально существует (защита от "нулевых" дат MySQL)
				$lastmod = '';

				if (!empty($product['date_modified']) && strtotime($product['date_modified'])) {
					$lastmod = $product['date_modified'];
				} elseif (!empty($product['date_added']) && strtotime($product['date_added'])) {
					$lastmod = $product['date_added'];
				}

				if ($lastmod) {
					$output .= '  <lastmod>' . date('Y-m-d\TH:i:sP', strtotime($lastmod)) . '</lastmod>' . "\n";
				}

				$output .= '  <priority>0.9</priority>' . "\n";

				// Главное фото товара — один image-блок (формат Google image sitemaps)
				if (!empty($product['image'])) {
					$image = $this->model_tool_image->resize($product['image'], 1000, 1000);

					if ($image) {
						$name = htmlspecialchars(html_entity_decode($product['name'], ENT_QUOTES, 'UTF-8'), ENT_XML1, 'UTF-8');

						$output .= '  <image:image>' . "\n";
						$output .= '    <image:loc>' . $image . '</image:loc>' . "\n";
						$output .= '    <image:title>' . $name . '</image:title>' . "\n";
						$output .= '    <image:caption>' . $name . '</image:caption>' . "\n";
						$output .= '  </image:image>' . "\n";
					}
				}

				$output .= '</url>' . "\n";
			}

			// ------------------------------------------------------------------
			// 3. КАТЕГОРИИ — рекурсивно, с полным путём (path=1_5_12),
			//    как того требует OpenCart для вложенных категорий
			// ------------------------------------------------------------------
			$this->load->model('catalog/category');

			$queue = array(array('parent_id' => 0, 'path' => ''));

			while ($queue) {
				$node = array_shift($queue);

				$categories = $this->model_catalog_category->getCategories($node['parent_id']);

				foreach ($categories as $category) {
					$path = ($node['path'] !== '' ? $node['path'] . '_' : '') . (int)$category['category_id'];

					$link = $this->url->link('product/category', 'path=' . $path);

					if (!isset($seen[$link])) {
						$seen[$link] = true;

						$output .= '<url>' . "\n";
						$output .= '  <loc>' . $link . '</loc>' . "\n";
						$output .= '  <changefreq>weekly</changefreq>' . "\n";

						if (!empty($category['date_modified']) && strtotime($category['date_modified'])) {
							$output .= '  <lastmod>' . date('Y-m-d\TH:i:sP', strtotime($category['date_modified'])) . '</lastmod>' . "\n";
						}

						$output .= '  <priority>0.8</priority>' . "\n";
						$output .= '</url>' . "\n";
					}

					// Спускаемся на уровень глубже
					$queue[] = array('parent_id' => (int)$category['category_id'], 'path' => $path);
				}
			}

			// ------------------------------------------------------------------
			// 4. ИНФОРМАЦИОННЫЕ СТРАНИЦЫ (Оплата, Помощь, и т.д.)
			//    Как только в SeoPro будут созданы ЧПУ, $this->url->link
			//    начнёт возвращать человеческие адреса автоматически.
			// ------------------------------------------------------------------
			$this->load->model('catalog/information');

			$informations = $this->model_catalog_information->getInformations();

			foreach ($informations as $information) {
				$link = $this->url->link('information/information', 'information_id=' . (int)$information['information_id']);

				if (isset($seen[$link])) {
					continue;
				}

				$seen[$link] = true;

				$output .= '<url>' . "\n";
				$output .= '  <loc>' . $link . '</loc>' . "\n";
				$output .= '  <changefreq>monthly</changefreq>' . "\n";
				$output .= '  <priority>0.5</priority>' . "\n";
				$output .= '</url>' . "\n";
			}

			$output .= '</urlset>';

			$this->response->addHeader('Content-Type: application/xml; charset=utf-8');
			$this->response->setOutput($output);
		}
	}

	public function install() {
	}

	public function uninstall() {
	}
}
