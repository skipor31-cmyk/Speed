const { PurgeCSS } = require('purgecss');
const fs = require('fs'); const zlib = require('zlib');
(async () => {
  const files = [
    ['../uploads/app.min.css', 'css-purged/app.min.css'],
    ['../uploads/bootstrap3.3.5.min.css', 'css-purged/bootstrap.min.css'],
    ['../uploads/custom.optimized.original.v2.2.css', 'css-purged/custom.optimized.original.v2.2.css'],
  ];
  const safelist = {
    standard: ['in','out','fade','show','active','open','collapsed','collapsing','collapse',
      'modal-open','modal-backdrop','dropdown-backdrop','sr-only','clearfix','disabled','hidden',
      'loading','loaded','selected','current','expanded','closed','animated','dragging'],
    greedy: [/^col-/,/^swiper/,/^fancybox/,/^modal/,/^tooltip/,/^popover/,/^carousel/,/^dropdown/,
      /^collapse/,/^countdown/,/^sticky/,/^priority-nav/,/^readmore/,/^hidden-/,/^visible-/,
      /^bs-/,/^is-/,/^has-/,/^fade/,/^mfp-/,/^anim/,/^no-js/,/^js/,/^print/,
      /^editor/,/^embed-responsive/,/^article__body/,/^article__blockquote/,/^Mso/,/^details__txt/]
  };
  for (const [src, out] of files) {
    const res = await new PurgeCSS().purge({
      content: ['crawl/*.html','home_live.html','product1.html','js/*.js'],
      css: [src], safelist, variables: false, keyframes: false, fontFace: false, rejected: true,
    });
    fs.writeFileSync(out, res[0].css);
    const b=fs.statSync(src).size, a=Buffer.byteLength(res[0].css);
    const gzB=zlib.gzipSync(fs.readFileSync(src)).length, gzA=zlib.gzipSync(Buffer.from(res[0].css)).length;
    console.log(`${src.split('/').pop()}: ${(b/1024)|0}KB -> ${(a/1024)|0}KB (-${Math.round(100-a/b*100)}%) | gzip ${(gzB/1024)|0}KB -> ${(gzA/1024)|0}KB | rejected: ${(res[0].rejected||[]).length}`);
    fs.writeFileSync(out+'.rejected.txt',(res[0].rejected||[]).join('\n'));
  }
})();
